package com.beyond.match.community.post.model.vo;

// 좋아요 기능
//public class Like {
//}