package com.beyond.match.user.model.vo;

public class FavoriteLocation {
}
