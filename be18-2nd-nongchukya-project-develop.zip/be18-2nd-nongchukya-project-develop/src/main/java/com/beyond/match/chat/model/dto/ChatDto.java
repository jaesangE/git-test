package com.beyond.match.chat.model.dto;

import lombok.Getter;

@Getter
public class ChatDto {
    private String senderNickname;
    private String message;
}