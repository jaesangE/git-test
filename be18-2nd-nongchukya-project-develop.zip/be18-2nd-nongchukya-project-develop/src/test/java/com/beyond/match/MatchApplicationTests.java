package com.beyond.match;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchApplicationTests {

    @Test
    void contextLoads() {
    }

}
