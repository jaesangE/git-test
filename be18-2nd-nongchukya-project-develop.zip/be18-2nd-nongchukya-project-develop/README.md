# be18-2nd-농구있네 축구싶냐 야구르징-project
[요구사항 정의서](https://docs.google.com/spreadsheets/d/1293Cmz0EkIeH163VswqcNQPK-0b8Cr8gXvtHyckqLN8/edit?gid=0#gid=0&fvid=1857363008)

[테이블 명세서](https://docs.google.com/spreadsheets/d/1293Cmz0EkIeH163VswqcNQPK-0b8Cr8gXvtHyckqLN8/edit?gid=99972625#gid=99972625)

[ERD](https://www.erdcloud.com/d/mrc7T5gfD8iZbYr8P)

[API 명세서](https://www.notion.so/API-24f80955955380be8f0deade40d16847)
